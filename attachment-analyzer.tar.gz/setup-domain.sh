#!/bin/bash

# Domain and SSL Setup Script for AttachmentAnalyzer
# Run this after the main deployment script

set -e

# Color codes
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

error() {
    echo -e "${RED}[ERROR] $1${NC}"
    exit 1
}

warning() {
    echo -e "${YELLOW}[WARNING] $1${NC}"
}

# Configuration
APP_NAME="attachment-analyzer"

# Get domain name from user
read -p "Enter your domain name (e.g., yourdomain.com): " DOMAIN_NAME

if [ -z "$DOMAIN_NAME" ]; then
    error "Domain name is required"
fi

log "Setting up domain: $DOMAIN_NAME"

# Get current server IP
SERVER_IP=$(curl -s http://ipinfo.io/ip)
log "Server IP: $SERVER_IP"

# Update Nginx configuration with domain name
log "Updating Nginx configuration..."
sudo sed -i "s/server_name _;/server_name $DOMAIN_NAME www.$DOMAIN_NAME;/" /etc/nginx/sites-available/$APP_NAME

# Test Nginx configuration
sudo nginx -t

# Reload Nginx
sudo systemctl reload nginx

# Check if domain points to this server
log "Checking DNS resolution..."
DOMAIN_IP=$(dig +short $DOMAIN_NAME | tail -n1)

if [ "$DOMAIN_IP" != "$SERVER_IP" ]; then
    warning "Domain $DOMAIN_NAME does not point to this server ($SERVER_IP)"
    warning "Current domain IP: $DOMAIN_IP"
    echo ""
    echo "Please update your DNS settings:"
    echo "1. Go to your domain registrar or DNS provider"
    echo "2. Create an A record pointing $DOMAIN_NAME to $SERVER_IP"
    echo "3. Create an A record pointing www.$DOMAIN_NAME to $SERVER_IP"
    echo "4. Wait for DNS propagation (can take up to 48 hours)"
    echo ""
    read -p "Press Enter when DNS is configured and propagated..."
fi

# Install SSL certificate
log "Installing SSL certificate with Let's Encrypt..."

# Stop nginx temporarily to avoid conflicts
sudo systemctl stop nginx

# Get SSL certificate
sudo certbot certonly --standalone -d $DOMAIN_NAME -d www.$DOMAIN_NAME --agree-tos --no-eff-email --email admin@$DOMAIN_NAME

# Start nginx
sudo systemctl start nginx

# Update Nginx config for SSL
log "Updating Nginx configuration for SSL..."
sudo tee /etc/nginx/sites-available/$APP_NAME > /dev/null << EOL
# Redirect HTTP to HTTPS
server {
    listen 80;
    server_name $DOMAIN_NAME www.$DOMAIN_NAME;
    return 301 https://\$server_name\$request_uri;
}

# HTTPS server
server {
    listen 443 ssl http2;
    server_name $DOMAIN_NAME www.$DOMAIN_NAME;
    
    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/$DOMAIN_NAME/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN_NAME/privkey.pem;
    
    # SSL Security
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers off;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    
    # Security headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy strict-origin-when-cross-origin;
    
    client_max_body_size 10M;
    
    # Main application
    location / {
        proxy_pass http://localhost:5001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 86400;
    }
    
    # WebSocket support
    location /ws {
        proxy_pass http://localhost:5001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "Upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # Static files
    location /uploads {
        alias /var/www/$APP_NAME/uploads;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # Health check
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
EOL

# Update Coturn configuration with domain
log "Updating Coturn configuration with domain..."
sudo sed -i "s/realm=localhost/realm=$DOMAIN_NAME/" /etc/turnserver.conf
sudo sed -i "s/server-name=localhost/server-name=$DOMAIN_NAME/" /etc/turnserver.conf

# Add SSL certificate to Coturn
sudo tee -a /etc/turnserver.conf > /dev/null << EOL
cert=/etc/letsencrypt/live/$DOMAIN_NAME/cert.pem
pkey=/etc/letsencrypt/live/$DOMAIN_NAME/privkey.pem
EOL

# Restart services
log "Restarting services..."
sudo nginx -t
sudo systemctl reload nginx
sudo systemctl restart coturn

# Update application environment with domain
log "Updating application environment..."
cd /var/www/$APP_NAME
sed -i "s/STUN_SERVER=stun:localhost:3478/STUN_SERVER=stun:$DOMAIN_NAME:3478/" .env
sed -i "s/TURN_SERVER=turn:localhost:3478/TURN_SERVER=turn:$DOMAIN_NAME:3478/" .env

# Restart application
pm2 restart $APP_NAME

# Test SSL certificate
log "Testing SSL certificate..."
if curl -s https://$DOMAIN_NAME/health > /dev/null; then
    log "✅ SSL certificate is working correctly!"
else
    warning "❌ SSL certificate test failed"
fi

# Display final summary
echo ""
echo "=== DOMAIN SETUP COMPLETE ==="
echo "Domain: https://$DOMAIN_NAME"
echo "SSL Certificate: ✅ Installed"
echo "Auto-renewal: ✅ Configured"
echo ""
echo "=== STUN/TURN Server ==="
echo "STUN: stun:$DOMAIN_NAME:3478"
echo "TURN: turn:$DOMAIN_NAME:3478"
echo ""
echo "=== Testing URLs ==="
echo "Main site: https://$DOMAIN_NAME"
echo "Health check: https://$DOMAIN_NAME/health"
echo ""
log "Domain setup completed successfully!" 