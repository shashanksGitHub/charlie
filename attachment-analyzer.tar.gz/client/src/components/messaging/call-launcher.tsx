import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Video, Settings, Lock } from "lucide-react";
import { VideoCall } from "@/components/ui/video-call";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";

interface CallLauncherProps {
  matchId: number;
  userId: number;
  receiverId: number;
  isDarkMode: boolean;
}

export function CallLauncher({
  matchId,
  userId,
  receiverId,
  isDarkMode,
}: CallLauncherProps) {
  const [open, setOpen] = useState(false);
  const [showPermissionDialog, setShowPermissionDialog] = useState(false);
  const [showHttpsDialog, setShowHttpsDialog] = useState(false);
  const { toast } = useToast();

  // Check if running on HTTPS or localhost
  const isSecureContext = window.isSecureContext;
  const isLocalhost = window.location.hostname === 'localhost' || 
                     window.location.hostname === '127.0.0.1' ||
                     window.location.hostname === '0.0.0.0';

  // Check browser support for WebRTC
  const hasWebRTCSupport = !!(window.RTCPeerConnection && 
                             navigator.mediaDevices &&
                             navigator.mediaDevices.getUserMedia);

  const checkMediaPermissions = async () => {
    try {
      // First check if we're in a secure context or localhost
      if (!isSecureContext && !isLocalhost) {
        setShowHttpsDialog(true);
        return;
      }

      // Check WebRTC support
      if (!hasWebRTCSupport) {
        toast({
          title: "Browser Not Supported",
          description: "Your browser doesn't support video calls. Please try using Chrome, Firefox, or Safari.",
          variant: "destructive"
        });
        return;
      }

      // Try to get permissions
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });

      // If successful, stop all tracks (we don't need them yet)
      stream.getTracks().forEach(track => track.stop());

      // Permissions granted, proceed with call
      setOpen(true);
    } catch (error) {
      console.error("Media permission error:", error);
      
      if ((error as Error).name === 'NotAllowedError' || 
          (error as Error).name === 'PermissionDeniedError') {
        setShowPermissionDialog(true);
      } else {
        toast({
          title: "Call Error",
          description: "Could not access camera or microphone. Please check your device settings.",
          variant: "destructive"
        });
      }
    }
  };

  return (
    <>
      <Button
        variant="ghost"
        size="icon"
        className={`rounded-full h-9 w-9 sm:h-11 sm:w-11 transition-all duration-200 ${
          isDarkMode
            ? "text-gray-300 hover:text-white hover:bg-gradient-to-br from-blue-500/20 to-blue-600/30"
            : "text-gray-600 hover:text-gray-900 hover:bg-gradient-to-br from-blue-500/10 to-blue-600/20"
        } hover:scale-105 group`}
        onClick={checkMediaPermissions}
      >
        <Video className="h-4 w-4 sm:h-5 sm:w-5 group-hover:scale-110 transition-transform" />
      </Button>

      <VideoCall
        matchId={matchId}
        userId={userId}
        receiverId={receiverId}
        open={open}
        onClose={() => setOpen(false)}
        isIncoming={false}
      />

      {/* HTTPS Requirement Dialog */}
      <Dialog open={showHttpsDialog} onOpenChange={setShowHttpsDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              HTTPS Required
            </DialogTitle>
            <DialogDescription>
              Video calls require a secure connection (HTTPS). Please access this application through a secure connection to use video calling features.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-4 py-4">
            <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
              <div className="flex-1">
                <h4 className="font-medium">How to fix this:</h4>
                <ol className="text-sm text-muted-foreground list-decimal list-inside mt-2">
                  <li>Access the app through an HTTPS URL</li>
                  <li>Or use localhost for development</li>
                  <li>Contact your administrator if needed</li>
                </ol>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowHttpsDialog(false)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Permission Request Dialog */}
      <Dialog open={showPermissionDialog} onOpenChange={setShowPermissionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Camera & Microphone Access Required</DialogTitle>
            <DialogDescription>
              To make video calls, we need permission to use your camera and microphone. 
              Please click "Allow" when your browser asks for permissions.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-4 py-4">
            <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
              <Settings className="h-6 w-6 text-muted-foreground" />
              <div className="flex-1">
                <h4 className="font-medium">How to enable permissions:</h4>
                <ol className="text-sm text-muted-foreground list-decimal list-inside mt-2">
                  <li>Click the camera icon in your browser's address bar</li>
                  <li>Select "Allow" for both camera and microphone</li>
                  <li>Refresh the page after enabling permissions</li>
                </ol>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowPermissionDialog(false)}
            >
              Close
            </Button>
            <Button
              onClick={() => {
                setShowPermissionDialog(false);
                checkMediaPermissions();
              }}
            >
              Try Again
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
